package model;

public class Repeater extends Player{
    private int id = 1;
    @Override
    public boolean strategy(SlotMachine slotmachine) {
        if(slotmachine.getRounds() == 1){
            return Constants.COOPERATION;
        }
        else{
            return opponentAction;
        }
    }
}
