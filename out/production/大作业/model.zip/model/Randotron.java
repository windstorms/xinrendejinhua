package model;

import java.util.Random;

public class Randotron extends Player{
    private int id = 8;
    @Override
    public boolean strategy(SlotMachine slotMachine) {
        Random random = new Random();
        int r = random.nextInt(100);
        if(r <= 50){
            return Constants.COOPERATION;
        }else{
            return Constants.DECEPTION;
        }
    }
}
