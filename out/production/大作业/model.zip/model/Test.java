package model;

public class Test {

    public static void main(String[] args) {
        SlotMachine sm = new SlotMachine();
        Player r1 = new Repeater();
        Player r2 = new Repeater();
        Player r3 = new Repeater();
        Player g1 = new Swindler();
        sm.fight(r1,r2);
        System.out.println(r1.getScore());
        System.out.println(r2.getScore());
        sm.setRounds(0);
        sm.fight(r3,g1);
        System.out.println(r3.getScore());
        System.out.println(g1.getScore());
    }
}
