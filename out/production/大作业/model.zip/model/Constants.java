package model;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;

import java.util.ArrayList;
import java.util.Arrays;

public class Constants {
    public static final boolean COOPERATION= true;
    public static final boolean DECEPTION= false;
    public static final int WIN_WIN = 2;
    public static final int DUPE_DUPE = 0;
    public static final int DUPE = 3;
    public static final int FOOLED = -1;
    public static final int DEFAULT_ROUNDS = 10;

    public static final String [] PLAYER_NAMES = {"复读机","老油条","小可爱","黑帮老铁",
                            "福尔摩斯","复读鸭","一根筋","胡乱来"};

    public static final Color REPEATER_COLOR = Color.rgb(48,93,226);
    public static final Color SWINDLER_COLOR = Color.rgb(17,23,91);
    public static final Color CUTIE_COLOR = Color.rgb(231,100,232);
    public static final Color GANGSTER_COLOR = Color.rgb(247,206,54);
    public static final Color HOLMES_COLOR = Color.rgb(159,125,11);
    public static final Color REREADDUCK_COLOR = Color.rgb(114,119,255);
    public static final Color SINGLEMIND_COLOR = Color.rgb(60,229,35);
    public static final Color RANDOTRON_COLOR = Color.rgb(243,38,57);

    public static final ArrayList<Color> PLAYER_COLORS = new ArrayList<Color>(Arrays.asList(
            REPEATER_COLOR,SWINDLER_COLOR,CUTIE_COLOR,GANGSTER_COLOR,
            HOLMES_COLOR,REREADDUCK_COLOR,SINGLEMIND_COLOR,RANDOTRON_COLOR));

    public static final int XBIAS = -45;
    public static final int YBIAS = -35;

    public static final boolean LOCKED = true;
    public static final boolean OPEN = false;
}
