package model;

public class Gangster extends Player{
    private int id = 4;
    private boolean fooled = false;
    @Override
    public boolean strategy(SlotMachine slotmachine) {
        if(slotmachine.getRounds() > 1 && opponentAction == Constants.DECEPTION){
            fooled = true;
        }
        if(fooled == false){
            return Constants.COOPERATION;
        }else{
            return Constants.DECEPTION;
        }
    }
}

