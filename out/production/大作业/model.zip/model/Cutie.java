package model;

public class Cutie extends Player{
    private int id = 3;
    @Override
    public boolean strategy(SlotMachine slotmachine) {
        return Constants.COOPERATION;
    }
}
