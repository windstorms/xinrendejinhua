package model;

public abstract class Player {
    protected boolean action;
    protected boolean opponentAction;
    private int id = 0;
    private int score = 0;

    public boolean isOpponentAction() {
        return opponentAction;
    }

    public void setOpponentAction(boolean opponentAction) {
        this.opponentAction = opponentAction;
    }

    public void setAction(boolean action) {
        this.action = action;
    }

    public void addScore(int num){
        score += num;
    }

    public int getScore() {
        return score;
    }

    abstract public boolean strategy(SlotMachine slotMachine);
}
