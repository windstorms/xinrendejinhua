package model;

import java.awt.*;

public class SingleMind extends Player{
    private int id = 7;
    private boolean fooled = false;

    @Override
    public boolean strategy(SlotMachine slotMachine) {
        if(slotMachine.getRounds() == 1){
            return Constants.COOPERATION;
        }
        else if(opponentAction == Constants.DECEPTION){
            return !action;
        }
        else{
            return action;
        }
    }
}
