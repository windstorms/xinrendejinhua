package model;

public class Holmes extends Player{
    private int id = 5;
    private boolean fooled = false;
    @Override
    public boolean strategy(SlotMachine slotmachine) {
        int rounds = slotmachine.getRounds();
        if(rounds <= 4){
            if(rounds > 1 && opponentAction == Constants.DECEPTION){
                fooled = true;
            }
            if(rounds % 2 == 1){
                return Constants.COOPERATION;
            }else{
                return Constants.DECEPTION;
            }
        }

        else{
            if(fooled == false){
                return Constants.DECEPTION;
            }else{
                return opponentAction;
            }
        }
    }
}
