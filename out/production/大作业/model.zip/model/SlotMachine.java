package model;

import java.util.Random;

public class SlotMachine {
    private int maxRounds = Constants.DEFAULT_ROUNDS;
    private int rounds = 0;
    private int win_win = Constants.WIN_WIN;
    private int dupe_dupe = Constants.DUPE_DUPE;
    private int dupe = Constants.DUPE;
    private int fooled = Constants.FOOLED;
    private int mistakeRate = 0;
    private Random random = new Random();

    public void setMistakeRate(int mistakeRate) {
        this.mistakeRate = mistakeRate;
    }

    public void setMaxRounds(int maxRounds) {
        this.maxRounds = maxRounds;
    }

    public void setWin_win(int win_win) {
        this.win_win = win_win;
    }

    public void setDupe_dupe(int dupe_dupe) {
        this.dupe_dupe = dupe_dupe;
    }

    public void setDupe(int dupe) {
        this.dupe = dupe;
    }

    public void setFooled(int fooled) {
        this.fooled = fooled;
    }

    public void setDefault(){
        win_win = Constants.WIN_WIN;
        dupe_dupe = Constants.DUPE_DUPE;
        dupe = Constants.DUPE;
        fooled = Constants.FOOLED;
    }

    public void setRounds(int rounds) {
        this.rounds = rounds;
    }

    public int getRounds() {
        return rounds;
    }

    public void fight(Player leftPlayer, Player rightPlayer){
        rounds++;
        boolean leftAction = leftPlayer.strategy(this);
        boolean rightAction = rightPlayer.strategy(this);
        int m1 = random.nextInt(100);
        int m2 = random.nextInt(100);
        if(m1 < mistakeRate){
            leftAction = !leftAction;
        }
        if(m2 < mistakeRate){
            rightAction = !rightAction;
        }
        leftPlayer.setAction(leftAction);
        rightPlayer.setAction(rightAction);
        leftPlayer.setOpponentAction(rightAction);
        rightPlayer.setOpponentAction(leftAction);

        if(leftAction == Constants.COOPERATION && rightAction == Constants.COOPERATION){
            leftPlayer.addScore(win_win);
            rightPlayer.addScore(win_win);
        }
        else if(leftAction == Constants.DECEPTION && rightAction == Constants.DECEPTION){
            leftPlayer.addScore(dupe_dupe);
            rightPlayer.addScore(dupe_dupe);
        }
        else if(leftAction = Constants.COOPERATION && rightAction == Constants.DECEPTION){
            leftPlayer.addScore(fooled);
            rightPlayer.addScore(dupe);
        }
        else{
            leftPlayer.addScore(dupe);
            rightPlayer.addScore(fooled);
        }
        return;
    }
}
