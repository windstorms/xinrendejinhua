package model;

public class RereadDuck extends Player{
    private int id = 6;
    private boolean fooled = false;
    @Override
    public boolean strategy(SlotMachine slotMachine) {
        if(slotMachine.getRounds() == 1){
            return Constants.COOPERATION;
        }
        else{
            if(opponentAction == Constants.COOPERATION){
                fooled = false;
                return Constants.COOPERATION;
            }
            else if(fooled == true){
                return Constants.DECEPTION;
            }
            else{
                fooled = true;
                return Constants.COOPERATION;
            }
        }
    }
}
