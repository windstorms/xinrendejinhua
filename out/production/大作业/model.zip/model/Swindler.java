package model;

public class Swindler extends Player{
    private int id = 2;
    @Override
    public boolean strategy(SlotMachine slotmachine) {
        return Constants.DECEPTION;
    }
}
